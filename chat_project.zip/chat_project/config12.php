<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='tutorial12_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>