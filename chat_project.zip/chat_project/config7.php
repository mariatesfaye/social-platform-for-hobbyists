<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='tutorial7_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>