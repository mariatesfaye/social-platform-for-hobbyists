<?php include "layouts/header.php"; ?>

<div class="container">

<center><h2 style="color:white; margin-top:10%;">
    <a href="chatpage.php" class="btn btn-primary">baking</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage2.php" class="btn btn-primary">swimming</a>&nbsp;&nbsp;&nbsp;
    <a href="chatpage3.php" class="btn btn-primary">dancing</a><br><br>
    <a href="chatpage4.php" class="btn btn-primary">singing</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage5.php" class="btn btn-primary">reading</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage6.php" class="btn btn-primary">coding</a><br><br>
    <a href="chatpage7.php" class="btn btn-primary">writing</a>&nbsp;&nbsp;&nbsp;
    <a href="chatpage8.php" class="btn btn-primary">watching<br>movies</a>&nbsp;&nbsp;
    <a href="chatpage9.php" class="btn btn-primary">drawing</a><br><br>
    <a href="chatpage10.php" class="btn btn-primary">hiking</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage11.php" class="btn btn-primary">pottery</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage12.php" class="btn btn-primary">sewing</a><br><br>
    <a href="chatpage13.php" class="btn btn-primary">cooking</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage14.php" class="btn btn-primary">acting</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="chatpage15.php" class="btn btn-primary">exercising</a>
</h2></center>
</div>

</body>
</html>
