<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='tutorial6_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>